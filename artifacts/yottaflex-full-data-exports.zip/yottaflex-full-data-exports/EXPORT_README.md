# YottaFlex full-volume synthetic exports

Generated using `python -m src.generator --output OUTPUT_DIR --seed 20261022 --scale 1.0`.

The export contains 200 requisitions, 5,000 candidates, 8,000 applications and 2,000 baseline interviews. The interview table has 2,003 rows after two labelled negative-case interviews and one reschedule-history row are retained. It includes CSV and JSON exports, a SQLite database, a portable SQL dump, a source manifest, a validation summary, SHA-256 checksums, and the separate ground-truth CSV/JSON.

All candidate/employee-like names and email addresses are synthetic. No external source data was used. Do not merge ground-truth files into model input features.

The full-volume validation passed. Two independent runs with the same seed produced identical CSV, JSON, SQL and metadata files across 35 files, with identical baseline row counts.
